curl -L https://toolbelt.treasuredata.com/sh/install-redhat-td-agent3.sh | sh

