curl -L https://toolbelt.treasuredata.com/sh/install-amazon1-td-agent3.sh | sh
