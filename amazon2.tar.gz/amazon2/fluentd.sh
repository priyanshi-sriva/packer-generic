curl -L https://toolbelt.treasuredata.com/sh/install-amazon2-td-agent3.sh | sh
